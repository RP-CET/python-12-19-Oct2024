phone = {"alan":80001234, "mary":90004567, "peter":61234567}

phone["mary"] = 91110000
del phone["peter"]