from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://www.fortytwo.sg/dining/dining-tables/ryder-round-table-black.html"
hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

#new-price
elements = soup.select("div.product-price:nth-child(5) > div:nth-child(1)") # $89.90 
price = elements[0].text
print("Current Price: " + elements[0].text)

#old-price
elements = soup.select("div.product-price:nth-child(5) > div:nth-child(2)")  #  $161.90
print("\nOld Price: " + elements[0].text)




import datetime

x = datetime.datetime.now()

helloFile = open("table.txt", "a")
helloFile.write(str(x) + "\tprice: " + price + "\n")
helloFile.close()
