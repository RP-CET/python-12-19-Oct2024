import json
import requests

url = "https://api.data.gov.sg/v1/environment/2-hour-weather-forecast"
req=requests.get(url)

data = json.loads(req.text)

name = data['items'][0]['forecasts'][0]["area"]
fc = FIX_ME
print ("name : {}, forecast : {}".format(name, fc))
