#Only M, y, o, i from "Mary Poppins" will be printed

name = "Mary Poppins"

i = 0
while i < len(FIX_ME):
    
    print (FIX_ME)
    
    i = FIX_ME
    